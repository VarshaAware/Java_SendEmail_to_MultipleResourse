package com.exilant.service;

import com.exilant.vo.SendEmail;


public interface SendEmailService {
	Boolean sendEmail(SendEmail sendEmail);
}
