package com.exilant.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.repository.SendEmailRepository;
import com.exilant.service.SendEmailService;
import com.exilant.vo.SendEmail;

@Service
public class SendEmailServiceImpl implements SendEmailService {
	@Autowired
	SendEmailRepository sendEmailRepository;

	@Override
	public Boolean sendEmail(SendEmail sendEmail) {
		return sendEmailRepository.sendEmail(sendEmail);
	}

}
