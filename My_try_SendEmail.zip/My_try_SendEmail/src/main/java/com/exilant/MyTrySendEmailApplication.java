package com.exilant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTrySendEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTrySendEmailApplication.class, args);
	}
}
