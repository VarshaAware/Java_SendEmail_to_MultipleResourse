package com.exilant.controller;



import org.springframework.http.ResponseEntity;

import com.exilant.vo.SendEmail;


public interface SendEmailController {
	ResponseEntity<?>sendEmail(SendEmail sendEmail) throws Exception;
}
