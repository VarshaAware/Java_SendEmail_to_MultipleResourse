package com.exilant.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Repository;

import com.exilant.repository.SendEmailRepository;
import com.exilant.vo.SendEmail;

@Repository
public class MySqlSendEmailRepository implements SendEmailRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlSendEmailRepository.class);
	private JavaMailSender javaMailSender;

	@Autowired
	public MySqlSendEmailRepository(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	@Override
	public boolean sendEmail(SendEmail sendEmail) {
		try {
			SimpleMailMessage mail = new SimpleMailMessage();
			mail.setFrom("jigyasa@exilant.com");

			String[] toArray = sendEmail.getTo().toArray(new String[sendEmail.getTo().size()]);
			mail.setTo(toArray);

			mail.setSubject(sendEmail.getSubject());
			mail.setText(sendEmail.getBody());
			javaMailSender.send(mail);
			return true;
		} catch (MailException e) {
			logger.error("mail exception");
			return false;
		}
	}

}
