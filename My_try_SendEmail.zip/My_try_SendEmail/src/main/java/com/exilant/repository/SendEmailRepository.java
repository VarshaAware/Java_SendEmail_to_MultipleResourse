package com.exilant.repository;

import com.exilant.vo.SendEmail;

public interface SendEmailRepository {
	boolean sendEmail(SendEmail sendEmail);
}
